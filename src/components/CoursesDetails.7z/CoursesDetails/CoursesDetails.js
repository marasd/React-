import React, {useState, useEffect } from 'react';
import { Card, CardImg, CardBody, CardTitle, CardSubtitle, CardText} from 'reactstrap';


const CoursesDetails = (props) => {
  const [myCourse, setMyCourse] = useState(props.location.course)
  const [instructors, setInstructors]=useState(props.location.instructors);
  

  useEffect(() => {
    console.log("refresh")
    if(JSON.parse(window.localStorage.getItem('course'))!= null){
      console.log("refresh course")
      setMyCourse(JSON.parse(window.localStorage.getItem('course')));
    }

    if(JSON.parse(window.localStorage.getItem('instructors'))!= null){
      console.log("refresh instructor")
      setInstructors(JSON.parse(window.localStorage.getItem('instructors'))); 
    }else if(instructors !== null){
      let instData=[];
      instructors.map(innerData =>{
      for(let i=0; i<myCourse.instructors.length; i++){  
          if(myCourse.instructors[i]==innerData.id){
          instData.push(innerData);   
          }           
        }
      })
      setInstructors(instData);
    }

  }, []);

  useEffect(() => {
    window.localStorage.setItem('course', JSON.stringify(myCourse));
  }, [myCourse]);

  useEffect(() => {
    window.localStorage.setItem('instructors', JSON.stringify(instructors));
  },[instructors]);



  {if(myCourse && myCourse != 5){
    return(
      <div  className="mt-4 ">
            <Card  className="col-8  mb-4 pb-4 mx-auto">
            <CardTitle id="cardtitle" className="p-2" tag="h1">{myCourse.title} ({myCourse.id})</CardTitle>  
            <CardImg top height="400px" width="100%" src={myCourse.imagePath} alt="Course's image" />
            <hr></hr>
            <CardBody>
              <CardSubtitle tag="h6" className="mb-2 text-muted">
                <div>
                  <div className="text-dark col-12 d-inline-flex flex-row justify-content-between">
                    <h4 className="col-4">Price: {myCourse.price.normal}&#8364;   </h4>
                    <h4 className="col-4">Duration: {myCourse.duration}</h4>
                  </div>
                  <div className="text-dark col-12 d-inline-flex flex-row justify-content-between">
                      <h4 className="col-4">Bookable:{myCourse.open? <span style={{color: 'green'}}>&#10003;</span> : <span>&#10060;</span>}</h4>
                      <h4 className="col-4">Dates: {myCourse.dates.start_date} - {myCourse.dates.end_date} </h4>
                  </div>
                </div>
              </CardSubtitle>
              <CardText  className="col-12 mt-4" dangerouslySetInnerHTML={{ __html: myCourse.description }}></CardText>
              <div className="text-dark col-12 d-inline-flex flex-row ">
                <a href="/edit_course" type="button"  className="btn btn-primary text-white mt-2 ">Edit</a>
                <a href="#" type="button"  className="btn btn-danger text-white mt-2 mx-1">Delete</a>
              </div>
              <h3>Instructors</h3> 
                  {instructors && instructors.map( post => {
                    return(<div>
                        <h3>{post.name.first} {post.name.last} ({post.dob})</h3> 
                        <p>Email: <span className="text-primary">{post.email}</span> | <a href={post.linkedin} className="no-decoration">LinkedIn</a> </p>
                        <p>{post.bio}</p>
                    </div>);
                  })} 
            </CardBody>
          </Card>
      </div> 
  )}else{
    return(
      <p>Do not play with url</p>
  )}}

}


export default CoursesDetails;
